https://discord.gg/altyapilar
